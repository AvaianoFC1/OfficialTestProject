package com.igorcordeiroszeremeta.MainCalc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.igorcordeiroszeremeta.MainCalc.R;

public class Calc extends AppCompatActivity {
    int result = 0;
    private CheckBox blue;
    private CheckBox red;
    private CheckBox yellow;
    private CheckBox green;
    private CheckBox black;
    private CheckBox white;
    private CheckBox orange;
    private CheckBox purple;
    private CheckBox gray;

    private TextView finalResultText;
    private Button button1, button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        blue = findViewById(R.id.blue);
        red = findViewById(R.id.red);
        yellow = findViewById(R.id.yellow);
        green = findViewById(R.id.green);
        black = findViewById(R.id.black);
        white = findViewById(R.id.white);
        orange = findViewById(R.id.orange);
        purple = findViewById(R.id.purple);
        gray = findViewById(R.id.gray);
        finalResultText = findViewById(R.id.finalResultText);

    }

    public int calculateResult() {
        if(red.isActivated()) {
            result +=10;
        } else if (blue.isActivated()) {
            result +=10;
        } else if (yellow.isActivated()) {
            result +=10;
        } else if (green.isActivated()) {
            result +=20;
        } else if(black.isActivated()) {
            result +=20;
        } else if(white.isActivated()) {
            result +=20;
        } else if(orange.isActivated()) {
            result +=30;
        } else if(purple.isActivated()) {
            result +=30;
        } else if(gray.isActivated()) {
            result +=30;
        }
        return result;
    }

    int finalSum = calculateResult();

    public void finalResult(int finalSum) {
        if(finalSum <= 60) {
            finalResultText.setText("Low Result");
        } else if(finalSum <= 120) {
            finalResultText.setText("Medium Result");
        } else {
            finalResultText.setText("High Result");
        }
    }

    public void openPage1() {
        Intent it = new Intent(getApplicationContext(),Page1.class);
        startActivity(it);
    }

    public void openPage2() {
        Intent it = new Intent(getApplicationContext(),Page2.class);
        startActivity(it);
    }
}
